package com.carwash.carservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.carwash.carservice.entity.Address;
import com.carwash.carservice.entity.Car;
import com.carwash.carservice.entity.CarResponse;
import com.carwash.carservice.exceptions.CarNotFoundException;
import com.carwash.carservice.repository.CarRepository;

@Service
public class CarServiceImpl implements CarService {

	@Autowired
	CarRepository carRepository;
	@Autowired
    private RestTemplate restTemplate;

	/*
	 * @Override public int addCar(Car car) { carRepository.save(car); return
	 * car.getCarId(); }
	 */
	
	@Override
	public CarResponse addCar(Car car) { 
		Car newCar=carRepository.save(car); 
		Address address= restTemplate.getForObject("http://localhost:8090/address/"+car.getAddressId(), Address.class);
		CarResponse carResponse=new CarResponse();
		carResponse.setCar(newCar);
		carResponse.setAddress(address);
		return carResponse;
		}
	
	@Override
	public List<Car> getAllCars() {
		return carRepository.findAll();
	}

	@Override
	public Optional<Car> getCarByCarId(int carId) {
		Optional<Car> car;
		if (carRepository.existsById(carId))
			car = carRepository.findById(carId);
		else
			throw new CarNotFoundException("Car doesnot exists...");
		return car;
	}

	@Override
	public void updateCar(Car car) {
		if (carRepository.existsById(car.getCarId()))
			carRepository.save(car);
		else
			throw new CarNotFoundException("Car doesnot exists...");
	}

	@Override
	public void deleteCar(int carId) {
		if (carRepository.existsById(carId))
			carRepository.deleteById(carId);
		else
			throw new CarNotFoundException("Car doesnot exists...");
	}
	
	@Override
	public boolean existsById(int carId) {
		return carRepository.existsById(carId);
	}

}
