package com.carwash.carservice.exceptions;

public class CarAlreadyExistsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CarAlreadyExistsException(String message) {
		super(message);
	}
	

}
