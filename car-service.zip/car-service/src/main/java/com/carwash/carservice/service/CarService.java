package com.carwash.carservice.service;

import java.util.List;
import java.util.Optional;

import com.carwash.carservice.entity.Car;
import com.carwash.carservice.entity.CarResponse;

public interface CarService {
	//int addCar(Car car);
	void updateCar(Car plan);
	Optional<Car> getCarByCarId(int carId);
	List<Car> getAllCars();
	void deleteCar(int carId);
	public CarResponse addCar(Car car);
	boolean existsById(int carId);

}
