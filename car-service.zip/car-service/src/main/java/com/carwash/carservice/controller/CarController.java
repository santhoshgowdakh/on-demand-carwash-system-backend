package com.carwash.carservice.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carwash.carservice.entity.Car;
import com.carwash.carservice.entity.CarResponse;
import com.carwash.carservice.service.CarService;

@RestController
@RequestMapping("/car")
public class CarController {

	@Autowired
	CarService carService;

	/*
	 * @PostMapping("/save") public ResponseEntity<String>
	 * addCar(@Valid @RequestBody Car car) { int carId = carService.addCar(car);
	 * return new ResponseEntity<String>("Car added ID: " + carId, HttpStatus.OK); }
	 */
	
	@PostMapping("/save")
	public ResponseEntity<CarResponse> addCar(@Valid @RequestBody Car car) {
		CarResponse carResponse = carService.addCar(car);
		return new ResponseEntity<>( carResponse, HttpStatus.CREATED);
	}

	@PutMapping("/update")
	public ResponseEntity<String> updateCar(@Valid @RequestBody Car car) {
		carService.updateCar(car);
		return new ResponseEntity<String>("Car updated", HttpStatus.OK);
	}

	@GetMapping("/id/{carId}")
	public ResponseEntity<Optional<Car>> getCarByCarId(@PathVariable int carId) {
		Optional<Car> car = carService.getCarByCarId(carId);
		return new ResponseEntity<Optional<Car>>(car, HttpStatus.OK);
	}

	@GetMapping("/list")
	public ResponseEntity<List<Car>> getAllCars() {
		List<Car> carList = carService.getAllCars();
		return new ResponseEntity<List<Car>>(carList, HttpStatus.OK);
	}

	@DeleteMapping("/{carId}")
	public ResponseEntity<String> deleteCar(@PathVariable int carId) {
		carService.deleteCar(carId);
		return new ResponseEntity<String>("Car deleted", HttpStatus.OK);
	}
	@GetMapping("/exists/{carId}")
	public ResponseEntity<Boolean> existsById(@PathVariable int carId){
		boolean exists=carService.existsById(carId);
		return new ResponseEntity<Boolean>(exists,HttpStatus.OK);
	}
}
